s=0
for i=1:100
    clc
    s=s+i
end
