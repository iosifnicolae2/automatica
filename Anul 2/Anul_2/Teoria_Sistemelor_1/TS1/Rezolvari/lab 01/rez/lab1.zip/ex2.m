s=0
i=1
while i<=100 &i>=1
    clc
     s=s+i
     i=i+1 ;
end