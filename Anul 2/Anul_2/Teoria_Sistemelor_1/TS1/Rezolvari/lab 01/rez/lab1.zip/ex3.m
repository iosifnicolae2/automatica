X=[1 0 2;0 0 1;0 0 4]
a=any(X)~=0
b=all(X)~=0
c=any(X)>-1