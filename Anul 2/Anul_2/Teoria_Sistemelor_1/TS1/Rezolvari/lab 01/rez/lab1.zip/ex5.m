X=[5 2 -9 10 -1 9 1]
s=0;
for i=1:7
    if X(i)<=8
        clc
    s=s+X(i)
    else break
    end
end